#include "student.h"
#include "course.h"

#include <sstream>

using namespace std;

ostream &operator<<(ostream &out, const Student &student) { return out; }
