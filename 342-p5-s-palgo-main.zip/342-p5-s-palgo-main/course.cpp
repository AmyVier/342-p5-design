#include "course.h"
#include "student.h"
#include <algorithm>
#include <cassert>
#include <sstream>

using namespace std;

ostream &operator<<(ostream &out, const Course &course) { return out; }
